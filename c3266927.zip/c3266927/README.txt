README.txt
Author: Emelie Ekenstedt
Last modified: 20/10/2016

Student number: c3266927

Files submitted in Assignment 2:

    index.html
    survey.html
    budget.xml
    luxury.xml
    roomstyle.xsl
    style.css

plus a directory called "images" containing all images used.

Comments about my Assignment 2:
-The links on the roompages are just made up since we haven't actualy created any page for storing the reviews.
-I added "gender" to the form to check for 3 different types of input-tags: text, dropdownlist and radiobuttons
-I used Firefox while designing these pages

Goals: Being visually attractive, easy to navigate through and giving a peaceful and welcoming impression